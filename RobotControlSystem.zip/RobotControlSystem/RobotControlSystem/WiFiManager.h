#ifndef WIFI_MANAGER_H
#define WIFI_MANAGER_H

#include <WiFi.h>
#include "esp_wifi.h"
#include "esp_wifi_types.h"

class WiFiManager {
private:
    IPAddress apIP;

public:
    WiFiManager();
    void begin(const char* ssid, const char* password, int channel = 1, int maxConnections = 4, bool hideSSID = false);
    IPAddress getAPIP() const { return apIP; }
    String getSSID() const;
    int getConnectedClients() const;
};

#endif
