#ifndef MOTOR_CONTROLLER_H
#define MOTOR_CONTROLLER_H

#include <Arduino.h>

// ���� ��� �������
#define MOTOR1_IN1              32
#define MOTOR1_IN2              33
#define MOTOR1_PWM              25
#define MOTOR2_IN1              26
#define MOTOR2_IN2              27
#define MOTOR2_PWM              14
#define MOTOR3_IN1              18
#define MOTOR3_IN2              19
#define MOTOR3_PWM              5
#define MOTOR4_IN1              21
#define MOTOR4_IN2              22
#define MOTOR4_PWM              23

// ��������� ���
#define PWM_FREQUENCY           5000
#define PWM_RESOLUTION          8
#define PWM_CHANNEL_MOTOR1      0
#define PWM_CHANNEL_MOTOR2      1
#define PWM_CHANNEL_MOTOR3      2
#define PWM_CHANNEL_MOTOR4      3

// ��������� ������������
#define MOTOR_TIMEOUT_MS        5000

enum MotorCommand {
    CMD_STOP,
    CMD_FORWARD,
    CMD_BACKWARD,
    CMD_LEFT,
    CMD_RIGHT
};

class MotorController {
private:
    int motorSpeeds[4];
    unsigned long lastCommandTime;
    bool motorsActive;
    MotorCommand currentCommand;

    void setAllMotorsSpeed(int s1, int s2, int s3, int s4);

public:
    MotorController();
    void begin();
    void moveForward(int speed);
    void moveBackward(int speed);
    void turnLeft(int speed);
    void turnRight(int speed);
    void stop();
    void update();  // �������� ��������
    bool areMotorsActive() const { return motorsActive; }
    unsigned long getLastCommandTime() const { return lastCommandTime; }
};

#endif
