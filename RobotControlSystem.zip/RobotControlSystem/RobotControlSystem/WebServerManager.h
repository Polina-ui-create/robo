#ifndef WEB_SERVER_MANAGER_H
#define WEB_SERVER_MANAGER_H

#include <WebServer.h>
#include "MotorController.h"
#include "ServoController.h"
#include "UserManager.h"
#include "html_pages.h"

class WebServerManager {
private:
    WebServer server;
    MotorController& motors;
    ServoController& servos;
    UserManager& users;

    unsigned long requestCount;
    unsigned long startTime;

    // �����������
    void handleRoot();
    void handleLogin();
    void handleLogout();
    void handleMotorControl();
    void handleServoControl();
    void handleStatus();
    void handlePing();
    void handleProfile();
    void handleAdmin();
    void handleApiUserInfo();
    void handleApiUsers();
    void handleApiPassword();

    // ��������������� ������
    bool isAuthorized(uint8_t requiredRole);
    String getSessionUser();
    int getUserIdByUsername(const String& username);

public:
    WebServerManager(MotorController& motorCtrl, ServoController& servoCtrl, UserManager& userMgr);
    void begin();
    void update();

    unsigned long getRequestCount() const { return requestCount; }
    unsigned long getUptime() const { return (millis() - startTime) / 1000; }
};

#endif
