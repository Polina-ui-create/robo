#ifndef USER_MANAGER_H
#define USER_MANAGER_H

#include <Arduino.h>
#include <EEPROM.h>

#define EEPROM_SIZE            512
#define EEPROM_MAGIC_NUMBER     0xAA
#define MAX_USERS               10
#define MAX_SESSIONS            5
#define SESSION_TIMEOUT         3600000  // 1 ���

enum UserRole {
    ROLE_GUEST = 0,
    ROLE_USER = 1,
    ROLE_ADMIN = 2
};

struct User {
    char username[20];
    char password[20];
    uint8_t role;
    bool isActive;
};

struct Session {
    char username[20];
    uint8_t role;
    unsigned long expiry;
    char sessionId[33];
};

class UserManager {
private:
    User users[MAX_USERS];
    Session activeSessions[MAX_SESSIONS];
    int userCount;
    int sessionCount;
    const uint8_t encryptionKey;

    String encryptString(const String& input);
    String decryptString(const String& input);
    String generateSessionId();
    void initDefaultAdmin();

public:
    UserManager(uint8_t key);
    void begin();
    void loadFromEEPROM();
    void saveToEEPROM();

    bool authenticate(const String& username, const String& password, uint8_t& role);
    String createSession(const String& username, uint8_t role);
    bool validateSession(const String& sessionId, uint8_t& role, String& username);
    void invalidateSession(const String& sessionId);

    bool changePassword(const String& username, const String& currentPassword, const String& newPassword);
    int getUserCount() const { return userCount; }
    int getSessionCount() const { return sessionCount; }
    const User* getUsers() const { return users; }
};

#endif
