#ifndef SECURITY_MANAGER_H
#define SECURITY_MANAGER_H

#include <Arduino.h>
#include "esp_flash_encrypt.h"

class SecurityManager {
public:
    static void checkFlashEncryption();
    static void setupPin15();
    static void printSecurityStatus();
};

#endif
