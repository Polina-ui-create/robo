#ifndef SERVO_CONTROLLER_H
#define SERVO_CONTROLLER_H

#include <ESP32Servo.h>

// ���� ��� �������������
#define SERVO_BASE              13
#define SERVO_SHOULDER          12
#define SERVO_ELBOW             4
#define SERVO_WRIST             16
#define SERVO_GRIPPER           17

#define SERVO_ANGLE_MIN         0
#define SERVO_ANGLE_MAX         180
#define SERVO_START_ANGLE       90
#define SERVO_UPDATE_INTERVAL_MS 15

enum ServoId {
    SERVO_BASE_ID = 0,
    SERVO_SHOULDER_ID,
    SERVO_ELBOW_ID,
    SERVO_WRIST_ID,
    SERVO_GRIPPER_ID,
    SERVO_COUNT
};

class SingleServoController {
private:
    int currentAngle;
    int targetAngle;
    int stepSize;
    unsigned long lastUpdate;
    bool moving;
    Servo* servo;

public:
    SingleServoController();
    void init(Servo* s, int initialPos);
    void setTarget(int angle);
    void update();
    int getCurrentAngle() const { return currentAngle; }
    bool isMoving() const { return moving; }
};

class ServoController {
private:
    Servo servoObjects[SERVO_COUNT];
    SingleServoController controllers[SERVO_COUNT];

public:
    ServoController();
    void begin();
    void setServoPosition(ServoId id, int angle);
    void update();
    int getServoPosition(ServoId id) const;
    bool isServoMoving(ServoId id) const;
};

#endif
